<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/success.css">

</head>
<body>
    <div class="container">
        <div class="card">
            <div class="img">
                </div>
                    <div class="textBox">
                        <div class="textContent">
                        <p class="h1">рядом рядом рядом</p>
                            <span class="span">секунду назад</span>
                        </div>
                        <p class="p">Ошибка! Попробуйте снова</p>
                    <div>
                </div>
            </div>
        </div>
    </div>
    <div class="container1">
        <button class="button" onclick="redirectToLoginPage()">Перейти к регистрации</button>
        <script>
        function redirectToLoginPage() {
            // Перенаправление на другой HTML файл (например, login.html)
            window.location.href = "/log_reg/register.html";
        }
        </script>
    </div>

</body>
</html>